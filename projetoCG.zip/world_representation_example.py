import numpy as np
import math
import pathlib
import sys

from core.base import Base
from core_ext.camera import Camera
from core_ext.mesh import Mesh
from core_ext.renderer import Renderer
from core_ext.scene import Scene
from extras.axes import AxesHelper
from extras.grid import GridHelper
from extras.movement_rig import MovementRig
from material.surface import SurfaceMaterial
from core_ext.render_target import RenderTarget
from core.obj_reader import my_obj_reader
from geometry.bar import BarGeometry
from core_ext.texture import Texture
from material.texture import TextureMaterial
from material.basic import BasicMaterial
from geometry.box import BoxGeometry  # 👈 Make sure this path matches your project structure
from material.emissive import EmissiveMaterial
from extras.postprocessor import Postprocessor
from effects.tintEffect import tintEffect
from effects.pixelateEffect import pixelateEffect
from effects.vignetteEffect import vignetteEffect
from effects.colorReduceEffect import colorReduceEffect
from effects.brightFilterEffect import brightFilterEffect
from effects.horizontalBlurEffect import horizontalBlurEffect
from effects.verticalBlurEffect import verticalBlurEffect
from effects.additiveBlendEffect import additiveBlendEffect
from geometry.rectangle import RectangleGeometry
from light.ambient import AmbientLight
from geometry.neonsign import NeonSignGeometry

class Example(Base):
    """
    Render the axes and the rotated xy-grid.
    Add camera movement: WASDRF(move), QE(turn), TG(look).
    """
    def initialize(self):
        print("Initializing program...")
        self.renderer = Renderer( clear_color=[0,0,0])
        self.scene = Scene()
        self.camera = Camera(aspect_ratio=1920/1080)
        self.mesh = BarGeometry(3, 3, 3, my_obj_reader('interior.obj'))
        box_geometry = BoxGeometry(width=1, height=1, depth=1)
        box_material = BasicMaterial()
        self.box = Mesh(geometry=box_geometry,material=box_material)
        self.box.translate(0, 1.5, 0) 
        self.scene.add(self.box)
        ambient_light = AmbientLight(color=[0.1, 0.1, 0.1])
        self.scene.add(ambient_light)
        self.rig = MovementRig()
        self.rig.add(self.camera)
        self.rig.set_position([0.5, 1.3, 5])
        self.scene.add(self.rig)
        self.scene.add(self.mesh)

        #NeonSign
        blue_geo, yellow_geo, black_geo = NeonSignGeometry(1, 1, 1, my_obj_reader('neonsign.obj'))
        self.bluesign_material = SurfaceMaterial(property_dict={"baseColor": [0.0, 1.0, 1.0]})
        self.yellowsign_material = SurfaceMaterial(property_dict={"baseColor": [1.0, 1.0, 0.0]})
        blacksign_material = SurfaceMaterial(property_dict={"baseColor": [0., 0, 0]})
        self.blueSign = Mesh(blue_geo,self.bluesign_material)
        self.yellowSign = Mesh(yellow_geo,self.yellowsign_material)
        blackSign = Mesh(black_geo,blacksign_material)

        self.blueSign.rotate_y(math.radians(90))
        self.blueSign.set_position([-14.9, 2, 10])
        self.yellowSign.local_matrix = self.blueSign.local_matrix
        blackSign.local_matrix = self.blueSign.local_matrix
        self.scene.add(self.blueSign)
        self.scene.add(self.yellowSign)
        self.scene.add(blackSign)


        self.postprocessor = Postprocessor(self.renderer,self.scene, self.camera)

        #glow scene
        self.glowScene = Scene()
        
        cyanMaterial = SurfaceMaterial(property_dict={"baseColor": [0,1,1]})
        glow_box = Mesh(box_geometry,cyanMaterial)
        glow_box.local_matrix = self.box.local_matrix
        self.glowScene.add(glow_box)

        self.neonBlueSign = Mesh(blue_geo,self.bluesign_material)
        self.neonYellowSign = Mesh(yellow_geo,self.yellowsign_material)
        self.neonBlueSign.local_matrix = self.blueSign.local_matrix
        self.neonYellowSign.local_matrix = self.yellowSign.local_matrix

        self.current_glow = self.neonBlueSign


        self.glowScene.add(self.current_glow)

        #glow postprocessing
        glow_target = RenderTarget(resolution=[800, 600])
        self.glow_pass = Postprocessor(self.renderer, self.glowScene, self.camera, glow_target)
        #self.postprocessor.add_effect(brightFilterEffect(1.4))
        self.glow_pass.add_effect( horizontalBlurEffect(texture_size=[800,600], blur_radius=50) )
        self.glow_pass.add_effect( verticalBlurEffect(texture_size=[800,600], blur_radius=50) )


        # combining results of glow effect with main scene
        self.combo_pass = Postprocessor(self.renderer, self.scene, self.camera)
        self.combo_pass.add_effect(
            additiveBlendEffect(
                blend_texture=glow_target.texture,
                original_strength=1,
                blend_strength=3
            )
        )



        #mainScene = self.postprocessor.render_target_list[0].texture
        #self.postprocessor.add_effect( additiveBlendEffect( blend_texture=mainScene, original_strength=2, blend_strength=1) )


        
        #HUD scene
        self.hudScene = Scene()
        self.hudCamera = Camera()
        self.hudCamera.set_orthographic(0,800,0,600,1,-1)
        labelGeo1 = RectangleGeometry(width=600,height=80,position=[0,600],alignment=[0,1])
        labelMat1 = TextureMaterial (Texture("images/Bar Simulator.png"))
        label1 = Mesh(labelGeo1,labelMat1)
        self.hudScene.add(label1)
        



    def update(self):
        #glow_strength = (math.sin(self.time * 2.0) + 1.0) / 2.0  # oscillates between 0 and 1
        #animated_color = [glow_strength * 1.0, glow_strength * 0.5, 0.1]
        #self.glow_material.uniform_dict["emissiveColor"].data = animated_color
        blink_interval = 1.0  # seconds
        blinking = int(self.time // blink_interval) % 2 == 0
        if blinking:
            # Blue ON, Yellow OFF
            next_glow = self.neonBlueSign
            self.bluesign_material = SurfaceMaterial(property_dict={"baseColor": [0,1,1]})
            self.yellowsign_material = SurfaceMaterial(property_dict={"baseColor": [0,0,0]})
            self.blueSign.material = self.bluesign_material
            self.yellowSign.material = self.yellowsign_material
        else:
            # Yellow ON, Blue OFF
            next_glow = self.neonYellowSign
            self.bluesign_material = SurfaceMaterial(property_dict={"baseColor": [0,0,0]})
            self.yellowsign_material = SurfaceMaterial(property_dict={"baseColor": [1,1,0]})
            self.blueSign.material = self.bluesign_material
            self.yellowSign.material = self.yellowsign_material

        # Reset glow scene and add the correct glowing mesh
        self.glowScene.remove(self.current_glow)
        self.glowScene.add(next_glow)
        self.current_glow = next_glow

        self.rig.update(self.input, self.delta_time)
        self.glow_pass.render()
        self.combo_pass.render()
        self.renderer.render( self.hudScene, self.hudCamera,clear_color=False)



# Instantiate this class and run the program
Example(screen_size=[1920, 1080]).run()
