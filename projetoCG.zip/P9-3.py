import numpy as np
import math
import pathlib
import sys

from core.base import Base
from core_ext.camera import Camera
from core_ext.mesh import Mesh
from core_ext.renderer import Renderer
from core_ext.scene import Scene
from geometry.mandolin import MandolinGeometry
from extras.axes import AxesHelper
from extras.grid import GridHelper
from extras.movement_rig import MovementRig
from material.surface import SurfaceMaterial
from core.obj_reader import my_obj_reader
from core_ext.texture import Texture
from material.texture import TextureMaterial


class Example(Base):
    """
    Render the axes and the rotated xy-grid.
    Mandollin movement: WASDRF(move), QE(turn), TG(look).
    Camera movement: Setas direcionais (move horizontally), BN (move vertically), ZX(turn), CV(look)
    """
    def initialize(self):
        print("Initializing program...")
        self.renderer = Renderer()
        self.scene = Scene()
        self.camera = Camera(aspect_ratio=800/600)
        self.camera.set_position([0.5, 1, 5])
        geometry = MandolinGeometry(1,1,1,my_obj_reader("mandolin.obj"))
        mandollin_texture = Texture(file_name="images/mandollintexture.png")
        material = TextureMaterial(texture=mandollin_texture)
        self.mesh = Mesh(
            geometry=geometry,
            material=material
        )
        self.rig = MovementRig()
        self.rig.add(self.mesh)
        self.rig2 = MovementRig()
        self.rig2.add(self.camera)
        self.rig.set_position([0, 0.5, -0.5])
        self.rig2.set_position([0, 0.5, -0.5])

        self.scene.add(self.rig)
        self.scene.add(self.rig2)

        self.rig2.KEY_MOVE_FORWARDS = "up"
        self.rig2.KEY_MOVE_BACKWARDS = "down"
        self.rig2.KEY_MOVE_LEFT = "left"
        self.rig2.KEY_MOVE_RIGHT = "right"
        self.rig2.KEY_MOVE_UP = "b"
        self.rig2.KEY_MOVE_DOWN = "n"
        self.rig2.KEY_TURN_LEFT = "z"
        self.rig2.KEY_TURN_RIGHT = "x"
        self.rig2.KEY_LOOK_UP = "c"
        self.rig2.KEY_LOOK_DOWN = "v"
        axes = AxesHelper(axis_length=2)
        self.scene.add(axes)
        grid = GridHelper(
            size=20,
            grid_color=[1, 1, 1],
            center_color=[1, 1, 0]
        )
        grid.rotate_x(-math.pi / 2)
        self.scene.add(grid)

    def update(self):
        self.rig.update(self.input, self.delta_time)
        self.rig2.update(self.input, self.delta_time)
        self.renderer.render(self.scene, self.camera)


# Instantiate this class and run the program
Example(screen_size=[800, 600]).run()