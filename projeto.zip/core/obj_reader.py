# credits: Margarida Moura, CGr 2022
#          Sergio Jesus, CG 2024 (modified)
#
"""Read vertices from OBJ file"""
def my_obj_reader(filename):
    vertices = []
    uvs = []
    materials = {}
    current_material = None

    with open(filename, 'r') as in_file:
        for line in in_file:
            tokens = line.strip().split()
            if not tokens:
                continue

            if tokens[0] == 'v':
                vertices.append([float(v) for v in tokens[1:]])
            elif tokens[0] == 'vt':
                uvs.append([float(v) for v in tokens[1:]])
            elif tokens[0] == 'usemtl':
                current_material = tokens[1]
                if current_material not in materials:
                    materials[current_material] = {"positions": [], "uvs": []}
            elif tokens[0] == 'f':
                face = [value.split('/') for value in tokens[1:]]
                for vertex_info in face:
                    v_idx = int(vertex_info[0]) - 1
                    t_idx = int(vertex_info[1]) - 1 if len(vertex_info) > 1 and vertex_info[1] else None
                    materials[current_material]["positions"].append(vertices[v_idx])
                    if t_idx is not None:
                        materials[current_material]["uvs"].append(uvs[t_idx])
                    else:
                        materials[current_material]["uvs"].append([0.0, 0.0])  # fallback

    # Convert to list of (material_name, positions, uvs)
    return [
        (mat_name, mat_data["positions"], mat_data["uvs"])
        for mat_name, mat_data in materials.items()
    ]